#include <iostream>
#include <algorithm>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <cstdio>

#define BOOKFILE "book.txt"
#define USERFILE "user.txt"
#define ADMINFILE "admin.txt"

using namespace std;

typedef struct
{
    int WholeNum;  //馆藏数量
    int LeftNum;   //剩余数量
    char name[100];    //图书名
    char ID[100];      //图书编号
    int RecordNum; //借阅条数
    char record[100][100];//借阅记录
}BOOK;

typedef struct
{
    int BorrowBookNum;    //借书数量
    char BorrowBook[10][100];    //借书名称,假令一个人同时最多借10本书
    char ID[100];                //用户ID
    char name[100];              //用户名字
}USER;

typedef struct
{
    char ID[100];              //管理员ID
    char password[100];        //管理员密码
}ADMIN;

vector<BOOK> book;
vector<USER> user;
vector<ADMIN> admin;

int AllUser;
int AllBook;
int AllAdmin;

/***************************************
              文件操作部分
***************************************/

//book部分的读与写
void OpenBookFile()
{
    FILE *bookinfo = fopen(BOOKFILE, "r");

    fscanf(bookinfo, "%d", &AllBook);
    for(int i = 0; i < AllBook; i ++ )
    {
        BOOK tmp;
        fscanf(bookinfo, "%d%d%s%s%d", &tmp.WholeNum, &tmp.LeftNum, tmp.name, tmp.ID, &tmp.RecordNum);
        for(int j = 0; j < tmp.RecordNum; j ++ )
            fscanf(bookinfo, "%s", tmp.record[j]);
        
        book.push_back(tmp);
    }

    fclose(bookinfo);
}

void PrintBookFile()
{
    FILE *bookprint = fopen(BOOKFILE, "w");

    fprintf(bookprint, "%d ", AllBook);
    for(int i = 0; i < AllBook; i ++ )
    {
        fprintf(bookprint, "%d %d %s %s %d ", book[i].WholeNum, book[i].LeftNum, book[i].name, book[i].ID, book[i].RecordNum);
        for(int j = 0; j < book[i].RecordNum; j ++ )
            fprintf(bookprint, "%s ", book[i].record[j]);
    }

    fclose(bookprint);
}

//admin部分的读与写
void OpenAdminFile()
{
    FILE *admininfo = fopen(ADMINFILE, "r");
    
    fscanf(admininfo, "%d", &AllAdmin);
    for(int i = 0; i < AllAdmin; i ++ )
    {
        ADMIN tmp;
        fscanf(admininfo, "%s%s", tmp.ID, tmp.password);
        admin.push_back(tmp);
    }

    fclose(admininfo);
}

void PrintAdminFile()
{
    FILE *adminprint = fopen(ADMINFILE, "w");
    fprintf(adminprint, "%d ", AllAdmin);
    for(int i = 0; i < AllAdmin; i ++ )
        fprintf(adminprint, "%s %s ", admin[i].ID, admin[i].password);

    fclose(adminprint);
}

//user部分的读与写
void OpenUserFile()
{
    FILE *userinfo = fopen(USERFILE, "r");
    fscanf(userinfo , "%d", &AllUser);
    for(int i = 0; i < AllUser; i ++ )
    {
        USER tmp;
        fscanf(userinfo ,"%s%s%d", tmp.name, tmp.ID, &tmp.BorrowBookNum);
        for(int j = 0; j < tmp.BorrowBookNum; j ++ )
            fscanf(userinfo, "%s", tmp.BorrowBook[j]);

        user.push_back(tmp);
    }

    fclose(userinfo);
}

void PrintUserFile()
{
    FILE *userprint = fopen(USERFILE, "w");
    fprintf(userprint, "%d ", AllUser);
    for(int i = 0; i < AllUser; i ++ )
    {
        fprintf(userprint, "%s %s %d ", user[i].name, user[i].ID, user[i].BorrowBookNum);
        for(int j = 0; j < user[i].BorrowBookNum; j ++ )
            fprintf(userprint, "%s ", user[i].BorrowBook[j]);
    }

    fclose(userprint);
}

/***************************************
             程序部分指令部分
***************************************/

//初始化函数，对文件进行读取
void InitOpen()
{
    OpenBookFile();
    OpenAdminFile();
    OpenUserFile();
}

//保存函数，每次操作后进行保存
void Save()
{
    PrintBookFile();
    PrintAdminFile();
    PrintUserFile();
}

//退出系统函数，直接结束程序
void ExistSys()
{
    cout << "感谢您的使用，再见！" << endl;
    system("pause");
    exit(0);
}

//展示书本信息函数
void ShowBookInfo(int i)
{
    cout << "以下为该本图书的具体信息：" << endl;
	cout << "【    书名    】: " << book[i].name << endl;
	cout << "【     ID    】: " << book[i].ID << endl;
	cout << "【  库存/馆藏  】: " << book[i].LeftNum << "/" << book[i].WholeNum << endl;
	cout << "【 借阅记录条数 】: " << book[i].RecordNum << endl;
}

//展示用户信息函数
void ShowUserInfo(int i)
{
    cout << "以下为该用户的具体信息：" << endl;
	cout << "【     姓名     】: " << user[i].name << endl;
	cout << "【      ID     】: " << user[i].ID << endl;
	cout << "【    借阅书数   】: " << user[i].BorrowBookNum << endl;
	cout << "【  具体书目如下  】: " << endl;
	for (int j = 0; j < user[i].BorrowBookNum; j ++ )
        cout << user[i].BorrowBook[j] << endl;
}

/***************************************
                管理员部分
***************************************/
//输出管理员的目录函数
void AdminMenu(char* id)
{
    cout << "亲爱的" << id << "，欢迎！" << endl;
    cout << "---------------请选择功能---------------" << endl;
    cout << "-------------1.录入图书信息-------------" << endl;
    cout << "-------------2.修改图书信息-------------" << endl;
    cout << "-------------3.删除图书信息-------------" << endl;
    cout << "-------------4.录入用户信息-------------" << endl;
    cout << "-------------5.修改用户信息-------------" << endl;
    cout << "-------------6.删除用户信息-------------" << endl;
    cout << "---------------7.退出系统---------------" << endl;
}

//输入库存图书函数
void BookEnter()
{
    int booknum;
    BOOK tmp;
    cout << "您好，请问您要录入几种书？" << endl;
    cin >> booknum;
    for(int i = 0 ; i < booknum; i ++ )
    {   
        cout << "请输入第" << i + 1 << "种图书的数量: ";
        cin >> tmp.WholeNum;
        tmp.LeftNum = tmp.WholeNum;
        cout << "请输入第" << i + 1 << "种图书的名字: ";
        cin >> tmp.name;
        cout << "请输入第" << i + 1 << "种图书的ID: ";
        cin >> tmp.ID;

        AllBook ++ ;
        book.push_back(tmp);
    }
    Save();
    cout << "您已成功完成录入！";

    system("pause");
    system("clc");
}

//对库存图书进行修改函数
void BookModify()
{
    int i;
    char bookid[30];
    int flag = 0;
    cout << "输入您想要修改的书籍的编号：" ;
    cin >> bookid;
    for(i = 0; i < AllBook; i ++ )
    {
        if(!strcmp(bookid, book[i].ID))
            {
                flag = 1;
                break;
            }
        flag = 0;
    }

    if(!flag)
        cout << "未找到您要修改的图书，请检查后重新输入！" << endl;
    else
    {
        ShowBookInfo(i);
        cout << "请选择以下修改操作：" << endl;
		cout << "1.修改书名" << endl;
		cout << "2.修改ID" << endl;
		cout << "3.修改馆藏数量" << endl;
        int choice;
        cin >> choice;

        int originNum = book[i].WholeNum;
        switch (choice)
        {
        case 1:
            cout << "请输入新书名: ";
            cin >> book[i].name;
            break;

        case 2:
            cout << "请输入新ID: ";
            cin >> book[i].ID;
            break;

        case 3:
            cout << "请输入新馆藏数: ";
            cin >> book[i].WholeNum;
            book[i].LeftNum += book[i].WholeNum - originNum;
            break;
        
        default:
            cout << "指令输入错误，请重新输入！";
            break;
        }
        cout << "您已经成功完成修改！" << endl;
        
        Save();
        system("pause");
        system("clc");
    }
}

//对库存图书进行删除函数
void BookDelete()
{
    int i;
    char bookid[30];
    int flag = 0;
    cout << "输入您想要删除的书籍的编号：" ;
    cin >> bookid;
    for(i = 0; i < AllBook; i ++ )
    {
        if(!strcmp(bookid, book[i].ID))
            {
                flag = 1;
                break;
            }
        flag = 0;
    }

    if(!flag)
        cout << "未找到您要删除的图书，请检查后重新输入！" << endl;
    else
    {
        book.erase(book.begin() + i);
        AllBook -- ;
        cout << "您已成功完成删除！" << endl;

        Save();
        system("pause");
        system("clc");
    }
}

//输入用户函数
void UserEnter()
{
    int userNum;
    cout << "您好，请问您要输入几位用户的信息？" << endl;
    cin >> userNum;
    for(int i = 0 ; i < userNum; i ++ )
    {
        USER tmp;
        cout << "请输入第" << i + 1 << "位用户的名字: " << endl;
		cin >> tmp.name;
		cout << "请输入第" << i + 1 << "位用户的ID: " << endl;
		cin >> tmp.ID;
		cout << "请输入第" << i + 1 << "位用户借书数: " << endl;
		cin >> tmp.BorrowBookNum;

        if(tmp.BorrowBookNum != 0)
        {
            for(int j = 0; j < tmp.BorrowBookNum; j ++ )
            {
                char bookID[30];
                int flag = 0, k = 0;
                cout << "请输入第" << j + 1 << "本书的编号: ";
                cin >> bookID;
                for(k = 0; k < AllBook; k ++ )
                {
                    if(!strcmp(bookID, book[k].ID))
                    {
                        flag = 1;
                        break;
                    }
                    flag = 0;
                }

                if(!flag)
                    cout << "输入失败，不存在此图书，请检查后重新输入！";
                else
                {
                    book[k].LeftNum -- ;
                    strcpy(book[k].record[book[k].RecordNum], tmp.ID);
                    book[k].RecordNum ++ ;
                    strcpy(tmp.BorrowBook[j], bookID);
                }
            }
        }

        AllUser ++ ;    //注意AllUser进行扩增
        user.push_back(tmp);
    }

    Save();
    cout << "您已完成录入！" << endl;
    system("pause");
    system("clc");
}

//对用户借书信息进行修改函数
void ModifyUserBook(int num)
{
    int j = 0, k = 0;
    int flag = 0;
    for(int i = 0; i < user[num].BorrowBookNum; i ++ )
    {
        for(j = 0; j < AllBook; j ++ )
        {
            flag = 0;
            if(!strcmp(user[num].BorrowBook[i], book[i].ID))
            {
                flag = 1;
                break;
            }
        }
        if(!flag)
            continue;
        else
        {
            book[j].LeftNum ++ ;
        }
    }

    cout << "请先输入新的借书数: " << endl;
    cin >> user[num].BorrowBookNum;
    for(int i = 0; i < user[num].BorrowBookNum; i ++ )
    {
        char bookid[30];
        cout << "请输入第" << i + 1 << "本图书编号" << endl;
        cin >> bookid;
        for(k = 0; k < AllBook; k ++ )
        {
            flag = 0;
            if(!strcmp(bookid, book[k].ID))
            {
                flag = 1;
                break;
            }
        }

        if(!flag)
            continue;
        else
        {
            book[k].LeftNum -- ;
            strcpy(book[k].record[book[k].RecordNum], user[num].ID);
            book[k].RecordNum ++ ;
        }
    }
}

//对用户信息进行修改函数
void UserModify()
{
    char userid[30];
    char bookid[30];
    int flag = 0;
    int i = 0;
    cout << "输入您要更改用户的ID: " << endl;
    cin >> userid;
    for(i = 0; i < AllUser; i ++ )
    {
        if(!strcmp(userid, user[i].ID))
        {
            flag = 1;
            break;
        }
        flag = 0;
    }

    if(!flag)
        cout << "查询失败，不存在此ID用户，请检查后再重新输入！" << endl;
    else
    {
        ShowUserInfo(i);
        cout << "请选择修改操作：" << endl;
		cout << "1.修改姓名" << endl;
		cout << "2.修改ID" << endl;
		cout << "3.修改借阅书籍" << endl;
        
        int choice;
        cin >> choice;
        switch (choice)
        {
        case 1:
            cout << "请输入新姓名: " << endl;
            cin >> user[i].name;
            break;
        
        case 2:
            cout << "请输入新ID: " << endl;
            cin >> user[i].ID;
            break;
        
        case 3:
            ModifyUserBook(i);
            break;

        default:
            cout << "指令输入错误，请重新输入！" << endl;
            break;
        }

        cout << "您已成功完成修改！" << endl;

        Save();
        system("pause");
        system("clc");
    }
}

//删除用户函数
void UserDelete()
{
    char userid[30];
    int flag = 0, i = 0;
    cout << "请输入您要删除用户的ID: " << endl;
    cin >> userid;
    for(i = 0; i < AllUser; i ++ )
    {
        flag = 0;
        if(!strcmp(userid, user[i].ID))
        {
            flag = 1;
            break;
        }
    }
    //若用户有未归还图书则不能删除用户
    if(!flag)
        cout << "删除失败，不存在该用户，请检查ID后重新输入！";
    else
    {
        if(user[i].BorrowBookNum != 0)
            cout << "删除失败，该用户仍有未归还图书！" << endl;
        else
        {
            user.erase(user.begin() + i);
            cout << "您已经成功删除该用户！" << endl;

            Save();
            system("pause");
            system("clc");
        }
    }
}

//判断管理员密码是否正确函数
bool isCorrectAdminPassword(char *id, char *password)
{
    for(int i = 0; i < AllAdmin; i ++ )
        if(!strcmp(id, admin[i].ID))
            if(!strcmp(password, admin[i].password))
                return true;
    
    return false;
}

//管理员功能的集合
void AdminMain(char* id)
{
    int choice;
    while(true)
    {
        AdminMenu(id);
        cin >> choice;
        switch (choice)
        {
        case 1:
            BookEnter();
            break;
        case 2:
            BookModify();
            break;
        case 3:
            BookDelete();
            break;
        case 4:
            UserEnter();
            break;
        case 5:
            UserModify();
            break;
        case 6:
            UserDelete();
            break;
        case 7:
            ExistSys();
            break;            
        default:
            cout << "请输入正确的指令！";
            break;
        }
        system("pause");
        system("cls");
    }
}

//判断是否为管理员
bool isAdmin(char* id)
{
    for(int i = 0; i < AllAdmin; i ++ )
        if(id == admin[i].ID)
            return true;

    return false;
}


/**************************************
                用户部分
**************************************/

//输出用户的目录函数
void UserMenu(char* id)
{
    cout << "亲爱的" << id << "，欢迎！" << endl;
    cout << "---------------请选择功能---------------" << endl;
    cout << "---------------1.我要借书---------------" << endl;
    cout << "---------------2.我要还书---------------" << endl;
    cout << "-------------3.查询图书信息-------------"  << endl;
    cout << "---------------4.退出系统---------------" << endl;
}

//用户借书的函数
void BorrowBook(int j)
{
    char bookid[30];
    int flag = 0, i = 0;
    cout << "请输入您要借的书的编号: " << endl;
    cin >> bookid;

    for(i = 0; i < AllBook; i ++ )
    {
        flag = 0;
        if(!strcmp(bookid, book[i].ID))
        {
            flag = 1;
            break;
        }
    }

    if(!flag)
        cout << "该图书不存在，请检查后重新输入！" << endl;
    else
    {
        if(book[i].LeftNum > 0)
        {
            book[i].LeftNum -- ;
            strcpy(user[j].BorrowBook[user[j].BorrowBookNum], bookid);
            user[j].BorrowBookNum ++ ;
            strcpy(book[i].record[book[i].RecordNum], user[j].ID);
            book[i].RecordNum ++ ;
            cout << "成功借出" << endl;
        }
        else
        {
            cout << "抱歉，该书已经全部借出，借书失败！" << endl;
            return;
        }
    }

    Save();
    system("pause");
    system("clc");
}

//用户还书函数
void ReturnBook(int j)
{
    char bookid[30];
    int flag = 0, i = 0;
    
    cout << "请输入您想归还的书的ID: " << endl;
    cin >> bookid;
    for(i = 0; i < AllBook; i ++ )
    {
        flag = 0;
        if(!strcmp(bookid, book[i].ID))
        {
            flag = 1;
            break;
        }
    }
    if(!flag)
        cout << "您要归还的图书不存在！" << endl;
    else
    {
        int flag2 = 0, k = 0;
        for(k = 0; k < user[j].BorrowBookNum; k ++ )
        {
            flag2 = 0;
            if(!strcmp(bookid, user[j].BorrowBook[k]))
            {
                flag2 = 1;
                break;
            }
        }

        if(!flag2)
            cout << "您并未借阅该图书，无法归还！" << endl;
        else
        {
            for(int l = k; l < user[j].BorrowBookNum; l ++ )
                strcpy(user[j].BorrowBook[l], user[j].BorrowBook[l + 1]);
            user[j].BorrowBookNum -- ;

            book[i].LeftNum ++ ;
            cout << "还书成功！" << endl;
        }
    }

    Save();
    system("pause");
    system("clc");
}

//找书函数
void SearchBook()
{
    char bookid[30];
    int flag = 0, i = 0;

    cout << "请输入您要查询图书的ID: " << endl;
    cin >> bookid;
    for(i = 0; i < AllBook; i ++ )
    {
        flag = 0;
        if(!strcmp(bookid, book[i].ID))
        {
            flag = 1;
            break;
        }
    }

    if(!flag)
        cout << "您查询的图书不存在！" << endl;
    else
        ShowBookInfo(i);

    system("pause");
    system("clc");
}

//寻找对应id的用户，在vector中的下角标
int findUser(char *id)
{
    for(int i = 0; i < AllUser; i ++ )
        if(!strcmp(id, user[i].ID))
            return i;
    return 0;
}

//user功能的集合
void UserMain(char* id)
{
    int i = findUser(id);
    int choice;
    while(true)
    {
        UserMenu(id);
        cin >> choice;
        switch (choice)
        {
        case 1:
            BorrowBook(i);
            break;
        case 2:
            ReturnBook(i);
            break;
        case 3:
            SearchBook();
        case 4:
            ExistSys();
            break;
        default:
            cout << "请输入正确的指令！";
            break;
        }
    }
}

//判断是否是用户
bool isUser(char* id)
{
    for(int i = 0; i < AllUser; i ++ )
        if(!strcmp(id, user[i].ID))
            return true;
    
    return false;
}


int main(int argc, char *argv[])
{
    cout << "您好，欢迎来到图书管理系统" << endl;
    InitOpen();
    char *id = argv[2];

    //判断用户输入是否正确，若正确则转到对应菜单
    if(!strcmp(argv[1], "-a"))  //判断是否为管理员
    
    {  
        //if(isAdmin(id))
            AdminMain(id);
        //else
         //   cout << "未查询到您的管理员信息，您没有权限访问" << endl;
    }
    else if(!strcmp(argv[1], "-u")) //判断是否为用户
    {  
        //if(isUser(id))
            UserMain(id);
        //else
        //    cout << "未查询到您的用户信息，您没有权限访问" << endl;
    }
    else    //若指令错误直接返回错误的信息
        cout << "错误的信息" << endl;

    return 0;
}