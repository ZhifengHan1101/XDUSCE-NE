#include <iostream>
#include <vector>

using namespace std;

// 判断实际上进行加法/减法的函数
bool AddSubjudge(string a, string b, int judge)
{
    //如果输入2（进行减法），则变成-1，之后若输入的两个数字之中，每有一个负数，judge * -1，最后若结果是 1 ，则为加法，否则减法
    if(judge == 2)
        judge = -1;
    if(a[0] == '-')
        judge *= -1;
    if(b[0] == '-')
        judge *= -1;
    if(judge == 1)
        return true;
    return false;
}

// 进行减法运算时，判断两数字大小，决定是否交换做差顺序的函数
bool cmp(vector<int> &A, vector<int> &B)
{
    //如果两个数字长度不一样，让长的做被减数
    //若长度相同，则从最高位开始比较，比较大的做被减数
    if (A.size() != B.size())
        return A.size() > B.size();
    
    for(int i = A.size() - 1; i >= 0; i -- )
        if(A[i] != B[i])
            return A[i] > B[i];
    
    return true;
}

//判断运算结果正负的函数
void PlusMinusJudge(string a, string b, bool judge1, bool judge2, int if0)
{
    //如果最后运算结果是0，则直接返回不需要再判断正负
    if(if0 == 0)
        return;

    //如果judge1为true（进行加法），且第一个数字为负数，则结果必为负数，否则为正数
    if(judge1 && a[0] == '-')
        printf("-");
    //如果judge1为false（进行减法）
    //当judge2为false（被减数和减数进行交换），则原来的被减数是正数，结果是负数，原来被减数是负数，结果是正数
    //当judge2为true（被减数和减数未进行交换）， 则原来的被减数是负数，结果是负数，原来被减数是正数，结果是正数
    else if(!judge1)
    {
        if(a[0] == '-' && judge2)
        { 
            printf("-");
            return;
        }
        else if(isdigit(a[0]) && !judge2)
        {
            printf("-");
            return;
        }
    }
}

//此处是实现高精度加法函数
vector<int> AddBigData(vector<int> &A, vector<int> &B)
{
    //若B比较长，交换后相加
    if(A.size() < B.size())
        return AddBigData(B, A);

    //定义t，作为中间介质，即借位数
    vector<int> C;
    int t = 0;
    for(int i = 0; i < A.size(); i ++ )
    {
        t += A[i];
        if(i < B.size())
            t += B[i];
        C.push_back(t % 10);
        t /= 10;
    }
    //最后t若不等于0，则再放入C中
    if(t)
        C.push_back(t);
    
    return C;
}


//此处是实现高精度减法函数
vector<int> MinusBigData(vector<int> &A, vector<int> &B)
{
    //定义t，做中间介质，即借位数
    vector<int> C;
    for(int i = 0, t = 0; i < A.size(); i ++ )
    {
        t = A[i] - t;
        if(i < B.size())
            t -= B[i];
        C.push_back((t + 10) % 10);
        if(t < 0)  
            t = 1;
        else
            t = 0;
    }
    
    //此处将C中的0全部弹出
    while(C.size() > 1 && C.back() == 0)
        C.pop_back();
    
    return C;
}

//此处是将string转换为vector<int>的函数
vector<int> TypeConversion(string num)
{
    vector<int> Num;
    for(int i = num.size() - 1; i >= 0; i -- )
        if(isdigit(num[i])) //除掉负号‘-’
            Num.push_back(num[i] - '0');
    
    return Num;
}

int main()
{
    //judge来判断用户表面上要进行加法/减法
    int judge;
    cout << "输入 1 进行加法\n输入 2 进行减法" << endl;
    cin >> judge;
    //num1，num2 为将要进行运算的两个数字的字符串形式
    string num1, num2;
    cout << "请依次输入进行计算的数字，数字间用空格分隔" << endl;
    cin >> num1 >> num2;
    //此处使用TypeConversion函数，将num1和num2转化成vector<int>形式，方便运算
    vector<int> A = TypeConversion(num1);
    vector<int> B = TypeConversion(num2);
    //ans来接收答案
    vector<int> ans;

    //此处，AddSubjudge函数来判断，实际上的运算需要通过加法还是减法进行，其结果储存在ASjudge中
    bool ASjudge = AddSubjudge(num1, num2, judge);
    //此处，将进行减法时，判断两个数字大小的函数结果储存在BSjudge中，方便后续对结果正负判断函数 PlusMinusJudge 的使用
    bool BSjudge = cmp(A, B);
    //实际需要加法，调用AddBigData函数
    if(ASjudge)
        ans = AddBigData(A, B);
    else
    //实际需要减法，根据给定的两个数字大小，选择MinusBigData函数参数的传入
        if(BSjudge)
            ans = MinusBigData(A, B);
        else
            ans = MinusBigData(B, A);

    //此处判断结果的正负，并输出负号
    PlusMinusJudge(num1, num2, ASjudge, BSjudge, ans.back());

    //输出结果
    for(int i = ans.size() - 1; i >= 0; i -- )
        cout << ans[i];
    
    return 0;
}