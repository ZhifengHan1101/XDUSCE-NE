#include <iostream>
#include <cstdio>

using namespace std;

const int N = 100010;
int stack[N];
int idx, m;

// 栈的push操作
void push(int x)
{
    // 将下一个元素放入数组中,当达到满栈时再放入会进行报错
    if(idx < N)
        stack[idx ++ ] = x;
    else
        printf("error");
}

//栈的pop操作
void pop()
{
    // 在idx下标非零时，使下表减1，从而完成pop操作
    if(idx)
        idx -- ;
    else
        printf("error\n");
}

//获取栈顶元素
int top()
{
    //返回下标为 idx-1 的元素，即为栈顶元素
    return stack[idx - 1];
}

//判断是否满栈
int isFull()
{
    //当下标 idx == N时，说明满栈
    if(idx == N)
        return 1;
    return 0;
}

//判断是否空栈
int isEmpty()
{
    //当下标 idx == 0时，说明空栈
    if(idx == 0)
        return 1;
    return 0;
}

int main()
{
    int n, cnt;
    while(1)
    {
        //输出指令，供用户输入
        printf("1.push\n2.pop\n3.top\n4.isFull\n5.isEmpty\nEnter -1 to stop the program\n");
        scanf("%d", &n);
        //设置退出循环的条件：n == -1
        if(n == -1)
            break;
        switch(n)
        {
            //push时，先输入要放入栈的数字个数，再进行放入
            case 1:
                printf("please enter the number of numbers you want to push\n");
                scanf("%d", &cnt);
                printf("please enter the number one by one\n");
                for(int i = 0; i < cnt; i ++ )
                {
                    scanf("%d", &m);
                    push(m);
                }
                break;
            //pop时，先输入要pop的数字个数，再弹出
            case 2:
                printf("please enter the number of numbers you want to pop\n");
                scanf("%d", &cnt);
                for(int i = 0; i < cnt; i ++ )
                    pop();
                break;
            //输出top元素
            case 3:
                printf("%d\n", top());
                break;
            //判断是否满栈
            case 4:
                if(isFull())
                    printf("the stack is full\n");
                else
                    printf("the stack is not full\n");
                break;
            //判断是否空栈
            case 5:
                if(!isEmpty())
                    printf("the stack is not empty\n");
                break;
            //当输入指令在 1，2，3，4，5之外时，让用户重新输入
            default:
                printf("please enter the correct instruction\n");
                break;
        }
        //每次操作后输出栈中所有元素
        for(int i = 0; i < idx; i ++ )
            printf("%d ", stack[i]);
        //当空栈时进行提醒/报错
        if(idx == 0)
            printf("the stack is empty");
        cout << endl;
    }
    return 0;
}
