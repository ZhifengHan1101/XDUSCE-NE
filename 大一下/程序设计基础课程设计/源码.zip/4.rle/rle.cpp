#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//实现压缩功能
void zip(char *inname, char *outname)
{
    //定义指向文件的指针
    FILE *in = fopen(inname, "rb"), *out = fopen(outname, "wb");
    //定义重复字符的长度
    int relen;
    //定义当前字符cur，和记录的重复字符tmp
    char cur, tmp;
    //当指针为空，说明文件打开失败
    if(in == NULL)
        printf("文件打开失败");
    else
    {
        //首先读取第一个字符，让储存在cur中，并令tmp = cur
        cur = fgetc(in);
        tmp = cur;
        //初始化relen = 1
        relen = 1;
        //当没有到文件末尾时，进行压缩操作
        while(!feof(in))
        {
            //读取下一个字符，并将此字符与上一个重复字符进行比较
            //若相等，则说明重复，此时令relen ++ 
            cur = fgetc(in);
            if(cur == tmp)
                relen ++ ;
            //若不相等，则说明重复字符结束，此时对之前的重复字符进行压缩并写入out文件中
            else
            {
                fputc(relen, out);  //写入二进制数
                fputc(tmp, out);    //写入重复的字符
                tmp = cur;          //令tmp等于下一个非重复的字符
                relen = 1;          //重制relen = 1
            }
        }
    }
    //关闭文件
    fclose(in);
    fclose(out);
}

//实现解压功能
void unzip(char *inname, char *outname)
{
    //定义指向文件的指针
    FILE *in = fopen(inname, "rb"), *out = fopen(outname, "wb");
    //定义并初始化relen = 1
    int relen = 1;
    char cur;
    //当指针为空，说明文件打开失败
    if(in == NULL)
        printf("文件打开失败");
    else
    {
        //当没有到达文件末尾时，进行解压操作
        while(!feof(in))
        {
            //获取relen的值（int）
            relen = fgetc(in);
            if(feof(in))    break;
            //获取重复的字符
            cur = fgetc(in);
            //进行写入
            while(relen -- )
                fputc(cur, out);
        }
    }
    //关闭文件
    fclose(in);
    fclose(out);
}

int main(int argc, char *argv[])
{
    /*
    //判断指令，进行压缩/解压缩
    if(!strcmp(argv[2], "-d"))
        //unzip(argv[1], argv[3]);
        unzip("toBeCompress.txt", "Compressed.txt");
    else if(!strcmp(argv[2], "-c"))
        //zip(argv[1], argv[3]);
        zip("toBeCompress.txt", "Compressed.txt");
    else
        printf("输入有误，请重新输入");
    */

   //zip("text1.txt", "text2.txt");
   unzip("text2.txt", "text3.txt");
    return 0;
}