<template>
  <div>
    <h2>Money Transfer</h2>
    <input type="text" v-model="account" placeholder="Enter recipient account number" />
    <input type="number" v-model="amount" placeholder="Enter amount to transfer" />
    <button @click="transferAmount">Transfer</button>
    <p v-if="message">{{ message }}</p>
  </div>
</template>

<script>
export default {
  name: 'MoneyTransfer',
  data() {
    return {
      account: '',
      amount: 0,
      message: ''
    };
  },
  methods: {
    transferAmount() {
      if (this.account && this.amount > 0) {
        // Normally, you'd call an API here
        this.message = `Successfully transferred $${this.amount} to account ${this.account}`;
      } else {
        this.message = 'Please enter a valid account and amount';
      }
    }
  }
};
</script>

<style scoped>
input {
  margin-right: 10px;
  padding: 5px;
  margin-bottom: 10px;
}
</style>