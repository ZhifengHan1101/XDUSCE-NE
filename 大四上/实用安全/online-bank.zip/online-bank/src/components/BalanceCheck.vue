<template>
  <div>
    <h2>Balance Check</h2>
    <button @click="checkBalance">Check Balance</button>
    <p v-if="balance !== null">Your balance is: ${{ balance }}</p>
  </div>
</template>

<script>
export default {
  name: 'BalanceCheck',
  data() {
    return {
      balance: null
    };
  },
  methods: {
    checkBalance() {
      // In a real application, this would fetch from an API
      this.balance = 1000; // Mock balance
    }
  }
};
</script>

<style scoped>
button {
  margin-top: 10px;
  padding: 10px;
}
</style>