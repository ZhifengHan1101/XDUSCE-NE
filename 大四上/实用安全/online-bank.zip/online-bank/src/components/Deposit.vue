<template>
  <div>
    <h2>Deposit</h2>
    <input type="number" v-model="amount" placeholder="Enter amount to deposit" />
    <button @click="depositAmount">Deposit</button>
    <p v-if="message">{{ message }}</p>
  </div>
</template>

<script>
export default {
  name: 'DepositPage',
  data() {
    return {
      amount: 0,
      message: ''
    };
  },
  methods: {
    depositAmount() {
      if (this.amount > 0) {
        // Normally, you'd call an API here
        this.message = `Successfully deposited $${this.amount}`;
      } else {
        this.message = 'Please enter a valid amount';
      }
    }
  }
};
</script>

<style scoped>
input {
  margin-right: 10px;
  padding: 5px;
}
</style>