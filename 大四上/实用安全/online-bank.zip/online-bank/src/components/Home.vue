<template>
  <div>
    <h1>Welcome to Online Bank</h1>
    <nav>
      <ul>
        <li><router-link to="/balance">Check Balance</router-link></li>
        <li><router-link to="/deposit">Deposit</router-link></li>
        <li><router-link to="/withdraw">Withdraw</router-link></li>
        <li><router-link to="/transfer">Money Transfer</router-link></li>
      </ul>
    </nav>
  </div>
</template>

<script>
export default {
  name: 'HomePage'
};
</script>

<style scoped>
ul {
  list-style-type: none;
}
li {
  margin: 10px 0;
}
nav {
  background-color: #f4f4f4;
  padding: 15px;
  border-radius: 5px;
}
</style>