<template>
  <div>
    <h2>Withdraw</h2>
    <input type="number" v-model="amount" placeholder="Enter amount to withdraw" />
    <button @click="withdrawAmount">Withdraw</button>
    <p v-if="message">{{ message }}</p>
  </div>
</template>

<script>
export default {
  name: 'WithdrawPage',
  data() {
    return {
      amount: 0,
      message: ''
    };
  },
  methods: {
    withdrawAmount() {
      if (this.amount > 0) {
        // Normally, you'd call an API here
        this.message = `Successfully withdrew $${this.amount}`;
      } else {
        this.message = 'Please enter a valid amount';
      }
    }
  }
};
</script>

<style scoped>
input {
  margin-right: 10px;
  padding: 5px;
}
</style>