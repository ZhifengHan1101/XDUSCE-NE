import { createRouter, createWebHashHistory } from 'vue-router';
import HomePage from '../components/Home.vue';
import BalanceCheck from '../components/BalanceCheck.vue';
import DepositPage from '../components/Deposit.vue';
import WithdrawPage from '../components/Withdraw.vue';
import MoneyTransfer from '../components/MoneyTransfer.vue';

const routes = [
  { path: '/', component: HomePage },
  { path: '/balance', component: BalanceCheck },
  { path: '/deposit', component: DepositPage },
  { path: '/withdraw', component: WithdrawPage },
  { path: '/transfer', component: MoneyTransfer },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;
