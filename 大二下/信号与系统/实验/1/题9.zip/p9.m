y = square_wave(200);
plot(linspace(0, 4*pi, 1001), y);
xlabel('t');
ylabel('y');
title('Square Wave');
beauty_plot;
